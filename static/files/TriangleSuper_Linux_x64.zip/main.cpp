#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <iostream>
#include <memory>
#include <cmath>
#include <Thor/Graphics.hpp>
#include <Thor/Shapes.hpp>
#include <Thor/Particles.hpp>
#include <Thor/Math.hpp>

#ifdef _WIN32
#define M_PI 3.14159
#endif

int getRandomInteger(double min, double max)
{
    double r = (double)rand() / (float)RAND_MAX;
    return min + r * (max - min);
}

template<typename V1>
void normalize(V1 &vector1)
{
    float length(sqrtf(vector1.x * vector1.x + vector1.y * vector1.y));
    vector1 /= length;
}

template<typename V1, typename V2>
V2 transformVector(const V1 &vector1, const float scale = 1.f)
{
    V2 vector2;
    vector2.x = vector1.x * scale;
    vector2.y = vector1.y * scale;
    return vector2;
}

class Particles
{
private:
    sf::Image Image;
    sf::Texture Texture;
    thor::ParticleSystem *System;
    sf::Clock Clock;
    thor::UniversalEmitter::Ptr Emitter;
    thor::Affector::Ptr Affector;
    float radius;

public:

    const thor::ParticleSystem &getSystem()
    {
        return *System;
    }

    void setPosition(sf::Vector2f position, float radius_ = -1.f)
    {
        if(radius_ < 0)
            radius_ = radius;
        Emitter->setParticlePosition(thor::Distributions::circle(position, radius_));
    }

    void Update()
    {
        System->update(Clock.restart());
    }

    void setColor(sf::Color color)
    {
        Image.create(Image.getSize().x, Image.getSize().y, color);
    }

    Particles(sf::Color color, int particleSize, int rate, sf::Vector2f force, sf::Vector2i timeRange,
              sf::Vector2f position, float radius_, sf::Vector2f direction, float maxRotation, sf::Vector2f rotation)
    {
        radius = radius_;
        Image.create(particleSize, particleSize, color);
        Texture.loadFromImage(Image);
        System = new thor::ParticleSystem(Texture);
        Emitter = thor::UniversalEmitter::create();
        Affector = thor::ForceAffector::create(force);
        System->addAffector(Affector);
        Emitter->setEmissionRate(rate);
        Emitter->setParticleLifetime(thor::Distributions::uniform(sf::seconds(timeRange.x), sf::seconds(timeRange.y)));
        Emitter->setParticlePosition(thor::Distributions::circle(position, radius));
        Emitter->setParticleVelocity(thor::Distributions::deflect(direction, maxRotation));
        Emitter->setParticleRotation(thor::Distributions::uniform(rotation.x, rotation.y));
        System->addEmitter(Emitter);
    }

};

class Enemy
{
private:
    Particles *particleSystem;
    thor::ConcaveShape shape;
    sf::Vector2f Destination, linearPosition, startingPoint;
    float angle;
    std::function<sf::Vector2f(sf::Vector2f, sf::Vector2f&, sf::Vector2f&, sf::Vector2f&, float&, float&)> algorithm;


public:

    void incrementColor()
    {
        sf::Color color = shape.getFillColor();
        if(color.a > 254)
        {
            if(color.r > 80)
                color.r--;
            else if(color.g > 80)
                color.g--;
            else if(color.b > 80)
                color.b--;
            else
                color.a--;
        }
        else
        {
            if(color.r < 255)
                color.r++;
            else if(color.g < 255)
                color.g++;
            else if(color.b < 255)
                color.b++;
            else
                color.a = 255;
        }
        shape.setFillColor(color);
        color.r -= 60;
        color.g -= 60;
        color.b -= 60;
        particleSystem->setColor(color);
    }

    const thor::ConcaveShape &getShape()
    {
        return shape;
    }

    void Update(float delaTime)
    {
        shape.setPosition(algorithm(shape.getPosition(), startingPoint, Destination, linearPosition, angle, delaTime));
        particleSystem->setPosition(shape.getPosition());
        particleSystem->Update();
    }

    void render(sf::RenderWindow &window)
    {
        window.draw((*particleSystem).getSystem());
        window.draw(shape);
    }

    Enemy(sf::Color color, sf::Vector2f position, sf::Vector2f Destination_,
          std::function<sf::Vector2f(sf::Vector2f, sf::Vector2f&, sf::Vector2f&, sf::Vector2f&, float&, float&)> algorithm_)
    {
        Destination = Destination_;
        algorithm = algorithm_;
        startingPoint = position;
        linearPosition = position;
        shape.setPointCount(4);
        shape.setPoint(0, sf::Vector2f(0,0));
        shape.setPoint(1, sf::Vector2f(10,5));
        shape.setPoint(2, sf::Vector2f(20,0));
        shape.setPoint(3, sf::Vector2f(10,15));
        shape.setFillColor(color);
        shape.setOrigin(10,5);
        shape.setPosition(position);
        sf::Vector2f direction(Destination - position);
        normalize(direction);
        (direction.x > 0) ? (shape.rotate(std::atan(direction.y / direction.x) * 180 / M_PI - 90)) : (shape.rotate(std::atan(direction.y / direction.x) * 180 / M_PI - 270));
        particleSystem = new Particles(sf::Color(color.r-100, color.b-100, color.g-100, color.a), 4, 10, sf::Vector2f(0.5f,0.5f), sf::Vector2i(0,3),
                                       position, 5.f, sf::Vector2f(5.f,5.f), 5.f, sf::Vector2f(0.f, 360.f));
    }

};

struct menuSystem
{
    sf::Text titleText, playText, quitText;
};

bool collides(Enemy &someEnemy, sf::Vector2f point)
{
    return sf::FloatRect{someEnemy.getShape().getPosition(), sf::Vector2f{20,15}}.contains(point);
}

int main()
{
    srand(time(NULL));
    sf::Clock gameClock;
    sf::Clock levelClock;
    unsigned int level{1}, levelCounter{0};

    std::function<sf::Vector2f(sf::Vector2f, sf::Vector2f&, sf::Vector2f&, sf::Vector2f&, float&, float)> enemyAISin =
    [](sf::Vector2f currentPosition, sf::Vector2f &startingPoint, sf::Vector2f &Destination, sf::Vector2f &linearPosition, float &angle, float deltaTime)
    {
        angle += 0.01 * deltaTime;
        sf::Vector2f direction = Destination - startingPoint;
        normalize(direction);
        float sinDeviation = sin(2 * angle) - 0.5;
        sf::Vector2f deviation(-direction.y, direction.x);
        deviation.x *= sinDeviation * 30.f;
        deviation.y *= sinDeviation * 30.f;
        linearPosition.x += direction.x * 300.f * deltaTime/1000.f;
        linearPosition.y += direction.y * 300.f * deltaTime/1000.f;
        return linearPosition + deviation;
    };

    std::function<sf::Vector2f(sf::Vector2f, sf::Vector2f&, sf::Vector2f&, sf::Vector2f&, float&, float)> enemyAILine =
    [](sf::Vector2f currentPosition, sf::Vector2f &startingPoint, sf::Vector2f &Destination, sf::Vector2f &linearPosition, float &angle, float deltaTime)
    {
        sf::Vector2f direction = Destination - startingPoint;
        normalize(direction);
        linearPosition.x += direction.x * 300.f * deltaTime/1000.f;
        linearPosition.y += direction.y * 300.f * deltaTime/1000.f;
        return linearPosition;
    };


    sf::Font mainFont;
    mainFont.loadFromFile("Arial.ttf");

    sf::Text textOverlay {"Current FPS: ", mainFont, 12};
    textOverlay.setPosition(5,5);

    sf::RenderWindow mainWindow(sf::VideoMode(800, 600), "LD26");
    mainWindow.setMouseCursorVisible(false);
    mainWindow.setFramerateLimit(1000);

    sf::View mainView;
    mainView.reset(sf::FloatRect(0.f,0.f,static_cast<float>(mainWindow.getSize().x), static_cast<float>(mainWindow.getSize().y)));
    mainView.setViewport(sf::FloatRect {0.f, 0.f, 1.f, 1.f});

    Particles stars(sf::Color::White, 1, 2, sf::Vector2f(0.1,0.1), sf::Vector2i(5, 10), sf::Vector2f(mainWindow.getSize().x/2, mainWindow.getSize().y/2), 400.f,
                    sf::Vector2f(0.1f, 0.1f), 80.f, sf::Vector2f(0.f, 360.f));

    float playerSize = 10.f;
    sf::CircleShape player(playerSize, 6);
    player.setFillColor(sf::Color(80,80,80,255));
    player.setOrigin(sf::Vector2f(playerSize,playerSize));

    std::vector<Enemy> Enemies;

    sf::Music mainMusic;
    mainMusic.openFromFile("LD26.ogg");
    mainMusic.setVolume(50.f);
    mainMusic.setLoop(true);
    mainMusic.play();

    bool gameStatus = true;

    menuSystem gameMenu;

    gameMenu.titleText.setFont(mainFont);
    gameMenu.titleText.setString("Triangle Super");
    gameMenu.titleText.setCharacterSize(72);
    gameMenu.titleText.setPosition(mainWindow.getSize().x/2 - gameMenu.titleText.getGlobalBounds().width/2.f,
                                   mainWindow.getSize().y/2 - gameMenu.titleText.getGlobalBounds().height/2.f);

    gameMenu.playText.setFont(mainFont);
    gameMenu.playText.setString("Play!");
    gameMenu.playText.setCharacterSize(30);
    gameMenu.playText.setPosition(mainWindow.getSize().x/3 - gameMenu.playText.getGlobalBounds().width/2.f,
                                 (mainWindow.getSize().y/3) *2 - gameMenu.playText.getGlobalBounds().height/2.f);

    gameMenu.quitText.setFont(mainFont);
    gameMenu.quitText.setString("Quit.");
    gameMenu.quitText.setCharacterSize(30);
    gameMenu.quitText.setPosition(mainWindow.getSize().x/3 *2 - gameMenu.quitText.getGlobalBounds().width/2.f,
                                    (mainWindow.getSize().y/3)*2-gameMenu.quitText.getGlobalBounds().height/2.f);


    while(mainWindow.isOpen())
    {

        if(gameStatus)
        {
            //Main Menu
            sf::Event mainEvent;
            while(mainWindow.pollEvent(mainEvent))
            {
                switch(mainEvent.type)
                {
                case sf::Event::Closed:
                    mainWindow.close();
                    break;

                case sf::Event::Resized:
                    mainView.setSize(sf::Vector2f(mainEvent.size.width, mainEvent.size.height));
                    mainWindow.setView(mainView);
                    break;

                case sf::Event::MouseMoved:
                    if(mainEvent.mouseMove.x > 0 && mainEvent.mouseMove.y > 0 &&
                    static_cast<unsigned int>(mainEvent.mouseMove.x) < mainWindow.getSize().x &&
                    static_cast<unsigned int>(mainEvent.mouseMove.y) < mainWindow.getSize().y)
                        player.setPosition(mainEvent.mouseMove.x, mainEvent.mouseMove.y);
                    break;

                case sf::Event::MouseButtonPressed:
                    if(gameMenu.playText.getGlobalBounds().contains(transformVector<sf::Vector2i, sf::Vector2f>(sf::Mouse::getPosition(mainWindow))))
                     {
                         gameStatus = false;
                         mainMusic.stop();
                         mainMusic.play();
                     }

                    else if(gameMenu.quitText.getGlobalBounds().contains(transformVector<sf::Vector2i, sf::Vector2f>(sf::Mouse::getPosition(mainWindow))))
                    {
                        mainMusic.stop();
                        mainWindow.close();
                    }
                    break;
                default:
                    break;

                }
            }
            mainWindow.clear(sf::Color::Black);
            stars.Update();
            mainWindow.draw(stars.getSystem());
            mainWindow.draw(player);
            mainWindow.draw(gameMenu.titleText);
            mainWindow.draw(gameMenu.playText);
            mainWindow.draw(gameMenu.quitText);
            mainWindow.display();
        }

        else if(!gameStatus)
        {
            //Game
            sf::Event mainEvent;
            while(mainWindow.pollEvent(mainEvent))
            {
                switch(mainEvent.type)
                {
                case sf::Event::Closed:
                    mainWindow.close();
                    break;

                case sf::Event::Resized:
                    mainView.setSize(sf::Vector2f(mainEvent.size.width, mainEvent.size.height));
                    mainWindow.setView(mainView);
                    break;

                case sf::Event::MouseMoved:
                    if(mainEvent.mouseMove.x > 0 && mainEvent.mouseMove.y > 0 &&
                    static_cast<unsigned int>(mainEvent.mouseMove.x) < mainWindow.getSize().x &&
                    static_cast<unsigned int>(mainEvent.mouseMove.y) < mainWindow.getSize().y)
                        player.setPosition(mainEvent.mouseMove.x, mainEvent.mouseMove.y);
                    break;

                case sf::Event::KeyPressed:
                    if(mainEvent.key.code == sf::Keyboard::Escape)
                    {
                        gameStatus = true;
                        Enemies.clear();
                        levelCounter = 0;
                        level = 1;
                    }
                    break;

                default:
                    break;

                }
            }
            if(levelClock.getElapsedTime().asMicroseconds()/1000.f > (1000.f*2)/level)
            {
                int randomInt = getRandomInteger(0,8);
                levelClock.restart();
                switch(randomInt)
                {
                case 0:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(-20.f, getRandomInteger(0, mainWindow.getSize().y)),
                                            sf::Vector2f(getRandomInteger(0, mainWindow.getSize().x), getRandomInteger(0, mainWindow.getSize().y)),
                                            enemyAISin));
                    break;
                case 1:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(mainWindow.getSize().x+20.f, getRandomInteger(0.f, mainWindow.getSize().y)),
                                            sf::Vector2f(getRandomInteger(0.f, mainWindow.getSize().x), getRandomInteger(0.f, mainWindow.getSize().y)),
                                            enemyAISin));
                    break;
                case 2:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(getRandomInteger(0, mainWindow.getSize().y), -20.f),
                                            sf::Vector2f(getRandomInteger(0, mainWindow.getSize().x), getRandomInteger(0, mainWindow.getSize().y)),
                                            enemyAISin));
                    break;
                case 3:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(getRandomInteger(0.f, mainWindow.getSize().y), mainWindow.getSize().x+20.f),
                                            sf::Vector2f(getRandomInteger(0.f, mainWindow.getSize().x), getRandomInteger(0.f, mainWindow.getSize().y)),
                                            enemyAISin));
                    break;
                case 4:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(-20.f, getRandomInteger(0, mainWindow.getSize().y)),
                                            sf::Vector2f(getRandomInteger(0, mainWindow.getSize().x), getRandomInteger(0, mainWindow.getSize().y)),
                                            enemyAILine));
                    break;
                case 5:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(mainWindow.getSize().x+20.f, getRandomInteger(0.f, mainWindow.getSize().y)),
                                            sf::Vector2f(getRandomInteger(0.f, mainWindow.getSize().x), getRandomInteger(0.f, mainWindow.getSize().y)),
                                            enemyAISin));
                    break;
                case 6:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(getRandomInteger(0, mainWindow.getSize().y), -20.f),
                                            sf::Vector2f(getRandomInteger(0, mainWindow.getSize().x), getRandomInteger(0, mainWindow.getSize().y)),
                                            enemyAILine));
                    break;
                case 7:
                    Enemies.push_back(Enemy(sf::Color::White,
                                            sf::Vector2f(getRandomInteger(0.f, mainWindow.getSize().y), mainWindow.getSize().x+20.f),
                                            sf::Vector2f(getRandomInteger(0.f, mainWindow.getSize().x), getRandomInteger(0.f, mainWindow.getSize().y)),
                                            enemyAISin));
                    break;

                default:
                    break;
                }
                levelCounter++;
                if(levelCounter > level * 10)
                    level++;
            }

            mainWindow.setView(mainView);
            mainWindow.clear(sf::Color(0,0,0,255));

            for(unsigned int i = 0; i < Enemies.size(); ++i)
            {
                Enemies[i].Update(gameClock.getElapsedTime().asMicroseconds()/1000.f);
                Enemies[i].incrementColor();
                Enemies[i].render(mainWindow);
                if(Enemies[i].getShape().getPosition().x > mainWindow.getSize().x + 100 ||
                   Enemies[i].getShape().getPosition().x < -100 ||
                   Enemies[i].getShape().getPosition().y > mainWindow.getSize().y + 100 ||
                   Enemies[i].getShape().getPosition().y < -100)
                    Enemies.erase(Enemies.begin()+i);

                if(collides(Enemies[i], player.getPosition()))
                {
                    gameStatus = true;
                    Enemies.clear();
                    levelCounter = 0;
                    level = 1;
                }
            }
            stars.Update();
            mainWindow.draw(stars.getSystem());
            textOverlay.setString(std::string{"Triangle Super\nCurrent FPS: "} + std::to_string( static_cast<int>(1000.f / (gameClock.getElapsedTime().asMicroseconds()/1000.f != 0.f ? gameClock.getElapsedTime().asMicroseconds()/1000.f : 1.f))) + std::string{"\nEntities: "} + std::to_string(Enemies.size()));
            mainWindow.draw(textOverlay);
            mainWindow.draw(player);
            mainWindow.display();
            gameClock.restart();
        }
    }
}

