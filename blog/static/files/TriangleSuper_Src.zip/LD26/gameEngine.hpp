#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <Box2D/Box2D.h>
#include <iostream>
#include <memory>

template<typename V1, typename V2>
V2 transformVector(const V1 &vector1, const float scale = 1.f)
{
    V2 vector2;
    vector2.x = vector1.x * scale;
    vector2.y = vector1.y * scale;
    return vector2;
}

template<typename V1, typename V2>
V2 *transformPoints(const V1 points1[], int amountOfPoints = 0, const float scale = 1.f)
{
    V2 points2[amountOfPoints];
    for(int i {0}; i < amountOfPoints; i++)
    {
        points2[i] = transformVector<V1, V2>(points1[i], scale);
        std::cout<<"Converting points: "<<points2[i].x<<", "<<points2[i].y<<std::endl;
    }
    return points2;
}

struct gameBody
{
    b2BodyDef bodyDef;
    b2Body* Body;
    b2PolygonShape polygonShape;
    b2FixtureDef fixtureDef;
    sf::Shape* Shape;
    bool active;
    unsigned int id;
};

class gameEngine
{
private:
    std::vector<gameBody> Bodies;

    b2World *gameWorld;
    unsigned int idCounter;
    int32_t velocityIterations, positionIterations;
    float timeStep;
    bool constStep;
    sf::Clock timeStepClock;
    struct
    {
        unsigned int bindID1, bindID2;
        b2MouseJointDef mouseJointDef;
        b2MouseJoint   *mouseJoint;

    } MouseJoint;


public:
    gameBody &operator[](unsigned int index);
    b2MouseJoint &getMouseJoint();
    unsigned int size();
    unsigned int createBox(sf::Vector2f boxSize, sf::Vector2f position, sf::Color color = sf::Color{0,0,0,255}, bool active = false, bool flip = false);
    unsigned int createCircle(float radius = 20, int pointcount = 30, sf::Vector2f position = sf::Vector2f{0,0}, sf::Color color = sf::Color{0,0,0,255}, bool active = false, bool flip = false);
    unsigned int createRectangle(sf::Vector2f dimensions, sf::Vector2f position = sf::Vector2f{0,0}, sf::Color color = sf::Color{0,0,0,255}, bool active = false, bool flip = false);
    unsigned int createShape(sf::Vector2f *points, unsigned int pointcount, sf::Vector2f position = sf::Vector2f{0,0}, sf::Color color = sf::Color{0,0,0,255}, bool active = false, bool flip = false);
    void createMouseJoint(unsigned int bodyID1, unsigned int bodyID2);
    void deleteMouseJoint();
    void setPosition(unsigned int id, sf::Vector2f position);
    void deleteBody(unsigned int id);
    void update();
    void draw(sf::RenderWindow &window);
    gameEngine(sf::Vector2f gravity, int32_t velocityIterations_, int32_t positionIterations_, float timeStep_);
};
