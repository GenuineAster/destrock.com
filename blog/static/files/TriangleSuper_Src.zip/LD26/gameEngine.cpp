#include "gameEngine.hpp"
#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <Box2D/Box2D.h>
#include <iostream>
#include <memory>


gameBody& gameEngine::operator[](unsigned int index){return Bodies[index];}
unsigned int gameEngine::size(){return Bodies.size();};

unsigned int gameEngine::createBox(sf::Vector2f boxSize, sf::Vector2f position, sf::Color color, bool active, bool flip)
{
    Bodies.push_back(gameBody());
    gameBody &newBody = Bodies[Bodies.size()-1];
    newBody.Shape = new sf::RectangleShape(boxSize);
    newBody.Shape->setFillColor(color);
    newBody.Shape->setPosition(position);
    if(flip)
        newBody.Shape->setScale(sf::Vector2f{1,-1});
    newBody.bodyDef.type = b2_staticBody;
    newBody.bodyDef.position.Set(position.x*0.1, position.y*0.1);
    newBody.Body = gameWorld->CreateBody(&newBody.bodyDef);
    newBody.polygonShape.SetAsBox(boxSize.x*0.1, boxSize.y*0.1);
    newBody.Body->CreateFixture(&newBody.polygonShape, 0.0f);
    idCounter++;
    newBody.id = idCounter;
    newBody.active = active;
    return idCounter;

}

unsigned int gameEngine::createCircle(float radius, int pointcount, sf::Vector2f position, sf::Color color, bool active, bool flip)
{
    Bodies.push_back(gameBody());
    gameBody &newBody = Bodies[Bodies.size()-1];
    newBody.Shape = new sf::CircleShape(radius, pointcount);
    newBody.Shape->setPosition(position);
    newBody.Shape->setFillColor(color);
    if(flip)
        newBody.Shape->setScale(sf::Vector2f{1,-1});
    newBody.bodyDef.type = b2_dynamicBody;
    newBody.bodyDef.position.Set(position.x*0.1, position.y*0.1);
    newBody.Body = gameWorld->CreateBody(&newBody.bodyDef);
    unsigned int newBodyPointCount = newBody.Shape->getPointCount();
    sf::Vector2f bodyPoints[newBodyPointCount];
    for(unsigned int i{0}; i < newBodyPointCount; ++i)
        bodyPoints[i] = newBody.Shape->getPoint(i);

    newBody.polygonShape.Set((transformPoints<sf::Vector2f, b2Vec2>(bodyPoints, newBodyPointCount, 0.1)), newBodyPointCount);
    newBody.fixtureDef.shape = &newBody.polygonShape;
    newBody.fixtureDef.density = 1.0f;
    newBody.fixtureDef.friction = 0.3f;
    newBody.Body->CreateFixture(&newBody.fixtureDef);
    idCounter++;
    newBody.id = idCounter;
    newBody.active = active;
    return idCounter;
}

unsigned int gameEngine::createRectangle(sf::Vector2f dimensions, sf::Vector2f position, sf::Color color, bool active, bool flip)
{
    Bodies.push_back(gameBody());
    gameBody &newBody = Bodies[Bodies.size()-1];
    newBody.Shape = new sf::RectangleShape(dimensions);
    newBody.Shape->setPosition(position);
    newBody.Shape->setFillColor(color);
    if(flip)
        newBody.Shape->setScale(sf::Vector2f{1,-1});
    newBody.bodyDef.type = b2_dynamicBody;
    newBody.bodyDef.position.Set(position.x*0.1, position.y*0.1);
    newBody.Body = gameWorld->CreateBody(&newBody.bodyDef);
    unsigned int newBodyPointCount = newBody.Shape->getPointCount();
    sf::Vector2f bodyPoints[newBodyPointCount];
    for(unsigned int i = 0; i < newBodyPointCount; i++)
        bodyPoints[i] = newBody.Shape->getPoint(i);

    newBody.polygonShape.Set((transformPoints<sf::Vector2f, b2Vec2>(bodyPoints, newBodyPointCount, 0.1)), newBodyPointCount);
    newBody.fixtureDef.shape = &newBody.polygonShape;
    newBody.fixtureDef.density = 1.0f;
    newBody.fixtureDef.friction = 0.3f;
    newBody.Body->CreateFixture(&newBody.fixtureDef);
    idCounter++;
    newBody.id = idCounter;
    newBody.active = active;
    return idCounter;
}

unsigned int gameEngine::createShape(sf::Vector2f *points, unsigned int pointcount, sf::Vector2f position, sf::Color color, bool active, bool flip)
{
    Bodies.push_back(gameBody());
    gameBody &newBody = Bodies[Bodies.size()-1];
    newBody.Shape = new sf::ConvexShape(pointcount);
    for(unsigned int i = 0; i < pointcount; i++)
        ((sf::ConvexShape*)newBody.Shape)->setPoint(i, points[i]);

    newBody.Shape->setPosition(position);
    newBody.Shape->setFillColor(color);
    if(flip)
        newBody.Shape->setScale(sf::Vector2f{1,-1});
    newBody.bodyDef.type = b2_dynamicBody;
    newBody.bodyDef.position.Set(position.x*0.1, position.y*0.1);
    newBody.Body = gameWorld->CreateBody(&newBody.bodyDef);
    unsigned int newBodyPointCount = newBody.Shape->getPointCount();
    sf::Vector2f bodyPoints[newBodyPointCount];
    for(unsigned int i{0}; i < newBodyPointCount; ++i)
        bodyPoints[i] = newBody.Shape->getPoint(i);

    newBody.polygonShape.Set((transformPoints<sf::Vector2f, b2Vec2>(bodyPoints, newBody.Shape->getPointCount(), 0.1)), newBody.Shape->getPointCount());
    newBody.fixtureDef.shape = &newBody.polygonShape;
    newBody.fixtureDef.density = 1.0f;
    newBody.fixtureDef.friction = 0.3f;
    newBody.Body->CreateFixture(&newBody.fixtureDef);
    idCounter++;
    newBody.id = idCounter;
    newBody.active = active;
    return idCounter;
}



void gameEngine::createMouseJoint(unsigned int bodyID1, unsigned int bodyID2)
{
    auto bodyA = std::find_if(Bodies.begin(), Bodies.end(), [bodyID1](const gameBody &body){return body.id == bodyID1;});
    MouseJoint.mouseJointDef.bodyA = (*bodyA).Body;
    auto bodyB = std::find_if(Bodies.begin(), Bodies.end(), [bodyID2](const gameBody &body){return body.id == bodyID2;});
    MouseJoint.mouseJointDef.bodyB = (*bodyB).Body;
    MouseJoint.mouseJointDef.target = ((*bodyA).Body->GetPosition());
    MouseJoint.mouseJointDef.maxForce = 10000;

    MouseJoint.mouseJoint = static_cast<b2MouseJoint*>(gameWorld->CreateJoint(&MouseJoint.mouseJointDef));
}

b2MouseJoint& gameEngine::getMouseJoint(){return *MouseJoint.mouseJoint;};

void deleteMouseJoint();



void gameEngine::setPosition(unsigned int id, sf::Vector2f position)
{
    auto it = std::find_if(Bodies.begin(), Bodies.end(), [id](const gameBody &body){return body.id == id;});
    (*it).Shape->setPosition(position);
    float oldAngle = (*it).Body->GetAngle();
    (*it).Body->SetTransform(transformVector<sf::Vector2f, b2Vec2>((*it).Shape->getPosition(), 0.1), oldAngle);

}

void gameEngine::deleteBody(unsigned int id)
{
    gameWorld->DestroyBody(Bodies[id].Body);
    for(unsigned int i = 0; i < Bodies.size(); ++i)
    {
        if(Bodies[i].id == id)
        {
            Bodies.erase(Bodies.begin() + i);
            return;
        }
    }
}

void gameEngine::update()
{
    if(constStep)
        timeStep = 1.f / (1000.f / timeStepClock.getElapsedTime().asMilliseconds());

    gameWorld->Step(timeStep, velocityIterations, positionIterations);

    for(unsigned int i{0}; i < Bodies.size(); ++i)
    {
        Bodies[i].Shape->setPosition(transformVector<b2Vec2, sf::Vector2f>(Bodies[i].Body->GetPosition(), 10));
    }
    //unsigned int someint = MouseJoint.bindID2;
    //auto mouseBody = std::find_if(Bodies.begin(), Bodies.end(), [someint](const gameBody &body){return body.id == someint;});
    // (*mouseBody).Shape->setPosition(transformVector<b2Vec2, sf::Vector2f>(getMouseJoint().GetBodyB()->GetPosition(), 10));
}

void gameEngine::draw(sf::RenderWindow &window)
{
    for(unsigned int i = 0; i < Bodies.size(); i++)
    {
        if(Bodies[i].active)
            window.draw(*Bodies[i].Shape);
    }
}

gameEngine::gameEngine(sf::Vector2f gravity, int32_t velocityIterations_, int32_t positionIterations_, float timeStep_)
{
    idCounter = 0;
    gameWorld = new b2World(transformVector<sf::Vector2f, b2Vec2>(gravity));
    (timeStep == 0.f) ? constStep = false : timeStep = timeStep_;
    if(constStep)
        timeStepClock.restart();
    velocityIterations = velocityIterations_;
    positionIterations = positionIterations_;
}
