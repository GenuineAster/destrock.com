#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <Box2D/Box2D.h>
#include <iostream>
#include <memory>
#include <cmath>
#include <Thor/Graphics.hpp>
#include <Thor/Particles.hpp>
#include <Thor/Math.hpp>

#ifdef _WIN32
#define M_PI 3.14159
#endif


template<typename V1, typename V2>
V2 transformVector(const V1 &vector1, const float scale = 1.f)
{
    V2 vector2;
    vector2.x = vector1.x * scale;
    vector2.y = vector1.y * scale;
    return vector2;
}

class Particles
{
private:
    sf::Image Image;
    sf::Texture Texture;
    thor::ParticleSystem *System;
    sf::Clock Clock;
    thor::UniversalEmitter::Ptr Emitter;
    thor::Affector::Ptr Affector;
    float radius;

public:
    const thor::ParticleSystem &getSystem()
    {
        return *System;
    }

    void setPosition(sf::Vector2f position, float radius_ = -1.f)
    {
        if(radius_ < 0)
            radius_ = radius;
        Emitter->setParticlePosition(thor::Distributions::circle(position, radius_));
    }

    void Update()
    {
        System->update(Clock.restart());
    }

    void setColor(sf::Color color)
    {
        Image.create(Image.getSize().x, Image.getSize().y, color);
    }

    Particles(sf::Color color, int particleSize, int rate, sf::Vector2f force, sf::Vector2i timeRange,
              sf::Vector2f position, float radius_, sf::Vector2f direction, float maxRotation, sf::Vector2f rotation)
    {
        radius = radius_;
        Image.create(particleSize, particleSize, color);
        Texture.loadFromImage(Image);
        System = new thor::ParticleSystem(Texture);
        Emitter = thor::UniversalEmitter::create();
        Affector = thor::ForceAffector::create(force);
        System->addAffector(Affector);
        Emitter->setEmissionRate(rate);
        Emitter->setParticleLifetime(thor::Distributions::uniform(sf::seconds(timeRange.x), sf::seconds(timeRange.y)));
        Emitter->setParticlePosition(thor::Distributions::circle(position, radius));
        Emitter->setParticleVelocity(thor::Distributions::deflect(direction, maxRotation));
        Emitter->setParticleRotation(thor::Distributions::uniform(rotation.x, rotation.y));
        System->addEmitter(Emitter);
    }

};

class Enemy
{
private:
    Particles *particleSystem;
    sf::ConvexShape shape;

public:

    const sf::ConvexShape &getShape()
    {
        return shape;
    }

    void Update(sf::Vector2f destination)
    {
        particleSystem->setPosition(shape.getPosition());
        particleSystem->Update();
        sf::Vector2f offset = destination - shape.getPosition();
        sf::Vector2f Signs;

        if(offset.x > 0)
            Signs.x = 1;
        else
            Signs.x = -1;

        if(offset.y > 0)
            Signs.y = 1;
        else
            Signs.y = -1;


        if(abs(offset.y) > abs(offset.x))
        {
            offset.x = fabs(offset.x / offset.y);
            offset.y = 1;
        }
        else
        {
            offset.y = fabs(offset.y / offset.x);
            offset.x = 1;
        }

        offset.x *= Signs.x;
        offset.y *= Signs.y;
        shape.move(offset / 5.f);
        shape.setRotation(std::atan(offset.y / offset.x) * 180 / M_PI);
    }

    void render(sf::RenderWindow &window)
    {
        window.draw((*particleSystem).getSystem());
        window.draw(shape);
    }

    Enemy(sf::Color color, sf::Vector2f position)
    {
        shape.setPointCount(3);
        shape.setPoint(0, sf::Vector2f(0,0));
        shape.setPoint(1, sf::Vector2f(0,10));
        shape.setPoint(2, sf::Vector2f(25,5));
        shape.setFillColor(color);
        shape.setOrigin(0,5);
        particleSystem = new Particles(sf::Color(color.r-200, color.b, color.g, color.a), 4, 10, sf::Vector2f(0.5f,0.5f), sf::Vector2i(0,3), position, 5.f, sf::Vector2f(20.f,25.f), 5.f, sf::Vector2f(0.f, 360.f));
    }
    ~Enemy()
    {
        delete particleSystem;
    }

};

int main()
{
    sf::RenderWindow mainWindow(sf::VideoMode(800, 600), "LD26");
    mainWindow.setMouseCursorVisible(false);
    mainWindow.setFramerateLimit(1000);

    sf::View mainView;
    mainView.reset(sf::FloatRect(0.f,0.f,static_cast<float>(mainWindow.getSize().x), static_cast<float>(mainWindow.getSize().y)));
    mainView.setViewport(sf::FloatRect {0.f, 0.f, 1.f, 1.f});

    Particles stars(sf::Color::White, 1, 10, sf::Vector2f(0.1,0.1), sf::Vector2i(20, 100), sf::Vector2f(mainWindow.getSize().x/2, mainWindow.getSize().y/2), 400.f,
                    sf::Vector2f(0.1f, 0.1f), 80.f, sf::Vector2f(0.f, 360.f));

    float playerSize = 10.f;
    sf::CircleShape player(playerSize, 6);
    player.setFillColor(sf::Color(80,80,80,255));
    player.setOrigin(sf::Vector2f(playerSize,playerSize));

    Enemy someEnemy(sf::Color::Red, transformVector<sf::Vector2i, sf::Vector2f>(mainWindow.getPosition()/2));

    while(mainWindow.isOpen())
    {
        sf::Event mainEvent;
        while(mainWindow.pollEvent(mainEvent))
        {
            switch(mainEvent.type)
            {
            case sf::Event::Closed:
                mainWindow.close();
                break;

            case sf::Event::Resized:
                mainView.setSize(sf::Vector2f(mainEvent.size.width, mainEvent.size.height));
                mainWindow.setView(mainView);
                break;

            case sf::Event::MouseMoved:
                if(mainEvent.mouseMove.x > 0 && mainEvent.mouseMove.y > 0 && static_cast<unsigned int>(mainEvent.mouseMove.x) < mainWindow.getSize().x && static_cast<unsigned int>(mainEvent.mouseMove.y) < mainWindow.getSize().y)
                    player.setPosition(mainEvent.mouseMove.x, mainEvent.mouseMove.y);
                break;

            case sf::Event::MouseWheelMoved:
                if(mainEvent.mouseWheel.delta > 0)
                    mainView.zoom(2);
                else
                    mainView.zoom(0.5);
                break;

            default:
                break;

            }
        }

        mainWindow.setView(mainView);
        mainWindow.clear(sf::Color(0,0,0,255));

        someEnemy.Update(player.getPosition());
        someEnemy.render(mainWindow);
        mainWindow.draw(player);

        stars.Update();
        mainWindow.draw(stars.getSystem());

        mainWindow.display();
    }
}
